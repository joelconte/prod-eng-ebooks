/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobstool;
 
import com.sun.org.apache.bcel.internal.generic.PUTFIELD;
import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Properties;
import java.util.Scanner;
import javax.net.ssl.HttpsURLConnection;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

 
public class JacobsTool extends javax.swing.JFrame {
    private boolean isNonIA = true;
    
    private int translationCount = 15; 
    private String[] translationKeys = {"title","creator","description",
    "subject","publisher","date","language","possible-copyright-status",
    "sponsor","contributor",   "mediatype","collection",
    "call_number","identifier","imagecount"};

    private String[] translationValues = {"dc:title","dc:creator","dc:description",
    "dc:subject","dc:publisher","dcterms:created","dc:language","dcterms:accessRights",
    "ldsterms:owninst","ldsterms:pubdigital","dc:format","dcterms:isPartOf",
    "ldsterms:callno3","dc:identifier","ldsterms:pagecount"};       
        
 
    private String[][] addedTagsKeys = {{"ldsterms:pubdigital","Internet Archive"},
        {"dcterms:isPartOf","Family History Archive - Internet Archive"},            
        {"ldsterms:filename","x"},
        {"ldsterms:filesize","x KB"},
        {"dc:rights","https://www.familysearch.org/terms"},
        {"ldsterms:mdentry","codepending"},
        {"dc:provenance","Digitization"},
        {"dcterms:hasVersion","Electronic Reproduction"},
        {"ldsterms:subinst","FHD"},
        {"ldsterms:mdentrytool","Internet Archive"},
        {"dcterms:requires","Internet Connectivity. Worldwide Web browser. Adobe Acrobat reader."},
        {"dc:source","Manuscript"},  
        {"dc:rightsHolder","Refer to document for copyright information"},
        {"dc:type","text"},
        {"dc:date","x"}};
 
    /*special logic
        -dcterms:accessRights Public if possible-copyright-status null or "Public" or "NOT_IN_COPYRIGHT" else content of tag
        -10/22/2016 changes to be all Public for IA books
    
    A few tags we can ignore as an FYI:  "scanningcenter","repub_state","operator""scanner" "updaetdate" "updater","uploader","addeddate" "publicdate", "ppi", "lcamid","rcamid","camera", 
        "foldoutcount","identifier-access","identifier-ark","scanfactors","curation",    
    /**
  
    */
    String[][]  recordValues = {{"eventIdentifierType","Provenance Event"},
        {"eventType","Scan"},
        {"eventDescription","Creation of image"},
        {"eventDateTime","x"},
        {"eventOutcome1","codepending"},
        {"eventOutcomeDetail1","Original image capture"},
        {"linkingAgentIdentifierType1","Image Capture"},
        {"linkingAgentIdentifierValue1","Internet Archive"}};
 
   
 
    public JacobsTool() {
        initComponents();
        processPropertiesFile();
    }

    public void processPropertiesFile(){
        Properties p = new Properties();
        try{
            p.load(new FileReader("jt.properties"));//put in same dir as executable jar or inside root project in netbeans
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error opening jt.properties file\n\nError Info:\n" + e.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog(this, "Looking in: " + System.getProperty("user.dir"), "Error", JOptionPane.ERROR_MESSAGE);
        }
        sourceLabel.setText(p.getProperty("sourceDir"));
        destinationLabel.setText(p.getProperty("destinationDir"));
        String isIABooks = p.getProperty("isIABooks");
        if(isIABooks.equals("true")){
            radioIA.setSelected(true);
        }else{
             radioNonIA.setSelected(true);
        }
        
        populateListBox(sourceLabel, filesListBox);
        populateListBox(destinationLabel, filesListBoxDest);
        
         
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        runButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        filesListBox = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        filesListBoxDest = new javax.swing.JList<>();
        srcPathLabel = new javax.swing.JLabel();
        saveProperties = new javax.swing.JButton();
        radioNonIA = new javax.swing.JRadioButton();
        radioIA = new javax.swing.JRadioButton();
        javax.swing.JButton setDir = new javax.swing.JButton();
        openSourceFolder = new javax.swing.JButton();
        javax.swing.JButton setDirDest = new javax.swing.JButton();
        openDestFolder = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        sourceLabel = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        destinationLabel = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Jacobs Tool Non IA Books - v2");

        runButton.setText("Run");
        runButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runButtonActionPerformed(evt);
            }
        });

        cancelButton.setText("Close");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(filesListBox);

        jScrollPane2.setViewportView(filesListBoxDest);

        saveProperties.setText("Remember Settings");
        saveProperties.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savePropertiesActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioNonIA);
        radioNonIA.setText("Non IA Books");

        buttonGroup1.add(radioIA);
        radioIA.setText("IA Books");

        setDir.setText("Set Source Location");
        setDir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setDirActionPerformed(evt);
            }
        });

        openSourceFolder.setText("Open Folder");
        openSourceFolder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openSourceFolderActionPerformed(evt);
            }
        });

        setDirDest.setText("Set Output Location");
        setDirDest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setDirDestActionPerformed(evt);
            }
        });

        openDestFolder.setText("Open Folder");
        openDestFolder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openDestFolderActionPerformed(evt);
            }
        });

        sourceLabel.setText("Source Dir");
        sourceLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sourceLabelActionPerformed(evt);
            }
        });
        jScrollPane3.setViewportView(sourceLabel);

        jScrollPane5.setViewportView(jScrollPane3);

        destinationLabel.setText("Destination Dir");
        destinationLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                destinationLabelActionPerformed(evt);
            }
        });
        jScrollPane4.setViewportView(destinationLabel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane5)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(setDir)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(openSourceFolder)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)))
                                .addGap(58, 58, 58)
                                .addComponent(saveProperties)
                                .addGap(37, 37, 37))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(setDirDest)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(openDestFolder)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(srcPathLabel)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(205, 205, 205)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(runButton)
                        .addGap(18, 18, 18)
                        .addComponent(cancelButton)
                        .addGap(81, 81, 81))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(radioNonIA)
                            .addComponent(radioIA))
                        .addGap(63, 63, 63))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(srcPathLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(jLabel1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(setDirDest)
                                    .addComponent(openDestFolder))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(52, 52, 52)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(setDir)
                                            .addComponent(openSourceFolder)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(5, 5, 5)
                                        .addComponent(radioIA, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(radioNonIA)))
                                .addGap(18, 18, 18)
                                .addComponent(saveProperties)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(runButton)
                    .addComponent(cancelButton))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void runButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runButtonActionPerformed
        // TODO add your handling code here:
        isNonIA = true;
        if(radioIA.isSelected())
            isNonIA = false;
        else
            isNonIA = true;
        
        String msg = "Confirm the following locations.\n\n Source directory--> " + sourceLabel.getText() + "\n"
                + " Destination directory--> " + destinationLabel.getText();
        
        if(JOptionPane.CANCEL_OPTION == JOptionPane.showConfirmDialog(this,  msg, "Continue?", JOptionPane.OK_CANCEL_OPTION))
            return;
            
        String sourcePath = sourceLabel.getText();
        String destinationPath = destinationLabel.getText();
        File sourceDir = new File(sourcePath);
        File[] sourceFiles = sourceDir.listFiles();
        File destinationDir = new File(destinationPath);
        //File[] destinationFiles = destinationDir.listFiles();
         
        //check if empty dest dir
        /*if(!isDestEmpty()){
            if(JOptionPane.CANCEL_OPTION == JOptionPane.showConfirmDialog(this,  msg, "Continue?", JOptionPane.OK_CANCEL_OPTION)){
                return;
            }
        }*/
        String msgs = "";
        boolean hadWarning = false;
        boolean hadError = false;
        for(File inFile : sourceFiles){
            msgs = "";
            try{
                
                msgs = processFile(inFile, destinationDir);
                if(msgs.contains("Error")){
                    hadError = true;
                }else  if(msgs.contains("Warning") || msgs.contains("WARNING")){
                    hadWarning = true;
                }
            
                    
                logBookProcessed( inFile.getName() , destinationDir );
                
            }catch(Exception e){
                msgs += e.getMessage()+"\r\n";
            }
            if(!msgs.equals(""))
                logErrors(msgs, destinationDir);
        }
        if(hadWarning == false && hadError == false){
            JOptionPane.showMessageDialog(this, "Complete with no errors");
        }else if(hadError == false){
            JOptionPane.showMessageDialog(this, "Complete with warnings.  Please see Errors.txt file in " + destinationLabel.getText());
        }else{
            JOptionPane.showMessageDialog(this, "Complete with errors.  Please see Errors.txt file." + destinationLabel.getText());
        }
        
        populateListBox(sourceLabel, filesListBox);
        populateListBox(destinationLabel, filesListBoxDest);
                
    }//GEN-LAST:event_runButtonActionPerformed


    private void logErrors(String msgs, File destDir){
        try{
            File errorFile = new File(destDir.getAbsolutePath()+"/Errors.txt");
            FileWriter fw = new FileWriter(errorFile,true);
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar cal = Calendar.getInstance();
            String dateStamp = dateFormat.format(cal.getTime());   
            
            if(msgs==null || msgs.equals(""))
                fw.append(dateStamp + "\r\nNo errors\r\n");
            else
                fw.append(dateStamp + "\r\n" + msgs+"\r\n");
             
            fw.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    private void logBookProcessed(String bookName, File destDir)throws Exception{
        
        String fileName = destDir.getName() + "_converted.txt";
        
        File f = new File(destDir.getAbsoluteFile() + "/" + fileName);
        FileWriter fw = new FileWriter(f, true);
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ");
        Calendar cal = Calendar.getInstance();
        String dateStamp = dateFormat.format(cal.getTime());   
            
        fw.append( bookName + " \t" + dateStamp + "\r\n");
             
        fw.close();
       
    }

    
    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        // TODO add your handling code here:
       
        System.exit(0);
    }//GEN-LAST:event_cancelButtonActionPerformed

    private void setDirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setDirActionPerformed
        // TODO add your handling code here:
        JFileChooser fc = new JFileChooser(sourceLabel.getText());
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int retVal = fc.showDialog(this, "Select Folder");
        if (retVal == JFileChooser.APPROVE_OPTION) {
            
            File dir = fc.getSelectedFile();
            sourceLabel.setText(dir.getAbsolutePath());
            
            populateListBox(sourceLabel, filesListBox);
        } else {
            //cancel
        }
    }//GEN-LAST:event_setDirActionPerformed

    private void setDirDestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setDirDestActionPerformed
        // TODO add your handling code here:
        JFileChooser fc = new JFileChooser(destinationLabel.getText());
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int retVal = fc.showDialog(this, "Select Folder");
        if (retVal == JFileChooser.APPROVE_OPTION) {
            
          
            File dir = fc.getSelectedFile();
            destinationLabel.setText(dir.getAbsolutePath());
            
            populateListBox(destinationLabel, filesListBoxDest);
        } else {
            //cancel
        }
    }//GEN-LAST:event_setDirDestActionPerformed

    private void sourceLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sourceLabelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sourceLabelActionPerformed

    private void savePropertiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savePropertiesActionPerformed

        Properties p = new Properties();
        try{
            p.load(new FileReader("jt.properties"));//put in same dir as executable jar or inside root project in netbeans
            p.setProperty("destinationDir", destinationLabel.getText());
            p.setProperty("sourceDir", sourceLabel.getText());
            String isIABooks = p.getProperty("isIABooks");
            if(radioIA.isSelected()){
                p.setProperty("isIABooks", "true");
            }else{
                p.setProperty("isIABooks", "false");
            }
        
            p.store(new FileWriter(new File("jt.properties")), null);
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error opening jt.properties file\n\nError Info:\n" + e.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog(this, "Looking in: " + System.getProperty("user.dir"), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_savePropertiesActionPerformed

    private void openSourceFolderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openSourceFolderActionPerformed
        // TODO add your handling code here:
       
        try{
        Desktop.getDesktop().open(new File(sourceLabel.getText()));
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Cannot open folder..." + e.getMessage());
        }
    }//GEN-LAST:event_openSourceFolderActionPerformed

    private void openDestFolderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openDestFolderActionPerformed
        
        try{
            Desktop.getDesktop().open(new File(destinationLabel.getText()));
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Cannot open folder..." + e.getMessage());
        }
    }//GEN-LAST:event_openDestFolderActionPerformed

    private void destinationLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_destinationLabelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_destinationLabelActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JacobsTool.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JacobsTool.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JacobsTool.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JacobsTool.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JacobsTool().setVisible(true);
            }
        });
    }

    private void populateListBox(JTextField dirField, JList list ){
        try{
        File dir = new File(dirField.getText());
                      
            File[] files = dir.listFiles();
            ListModel<String> m = list.getModel();
            DefaultListModel listModel = new DefaultListModel();
            
            for(File f : files){
                
                listModel.addElement(f.getName());   
            }
            
            list.setModel(listModel);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Problem reading directory: " + dirField.getText());
            System.out.println(e);
            e.printStackTrace();
        }
    }
    
    private boolean isDestEmpty(){
        File f = new File(destinationLabel.getText());
        File[] files = f.listFiles();
        if (!f.isDirectory() || files.length!=0)
             return false;
        else
            return true;
    }

    private void copyFile(File sourceFile, File destFile) throws IOException {
        if (!destFile.exists()) {
            destFile.createNewFile();
        }

        FileChannel source = null;
        FileChannel destination = null;

        try {
            source = new FileInputStream(sourceFile).getChannel();
            destination = new FileOutputStream(destFile).getChannel();
            destination.transferFrom(source, 0, source.size());
        } finally {
            if (source != null) {
                source.close();
            }
            if (destination != null) {
                destination.close();
            }
        }
    }

    /*
    INPUT

R:\Internet Archives\Elder Shaver Downloads\In Process
\2016_04_28_IA_Florida_Mar_2016\airforceregiste1962wash_0 
Contains airforceregiste1962wash_0.pdf and airforceregiste1962wash_0_meta.xml


OUTPUT
    no drps used
1. (Spence says these are not needed) 
 
2.  
R:\Internet Archives\Elder Shaver Downloads\In Process\2016_04_28_IA_Florida_Mar_2016_converted\dcms
\assets\airforceregiste1962wash_0\PRESERVATION_MASTER\
Contains airforceregiste1962wash_0.pdf

3.  
R:\Internet Archives\Elder Shaver Downloads\In Process\2016_04_28_IA_Florida_Mar_2016_converted\dcms
\metadata\ldssip
Contains all *.sip files in same dir (airforceregiste1962wash_0.sip.xml)

4. 
R:\Internet Archives\Elder Shaver Downloads\In Process\2016_04_04_British Columbia_3_Mar_converted
Contains 2016_04_04_British Columbia_3_Mar_converted.txt of all books
0000000000	4/1/2016 17:00
1000islandhouses00alex	4/1/2016 17:00
10thcensus0112unit	4/1/2016 17:00
10thcensus1096unit	4/1/2016 17:01
10thcensus1289unit	4/28/2016 15:36
12thcensusofpopu1372unit	4/1/2016 17:02
12thcensusofpopu1373unit	4/1/2016 17:03
12thcensusofpopu1546unit	4/1/2016 17:04
12thcensusofpopu1608unit	4/1/2016 17:05
13thcensus1910po1309unit	4/1/2016 17:06
13thcensus1910po1310unit	4/1/2016 17:08
13thcensus1910po1475unit	4/1/2016 17:09
13thcensus1910po1527unit	4/1/2016 17:10
14thcensusofpopu1507unit	4/1/2016 17:11
14thcensusofpopu1508unit	4/1/2016 17:13

     */

    //inDir //R:\Internet Archives\Elder Shaver Downloads\In Process\2016_04_28_IA_Florida_Mar_2016\airforceregiste1962wash_0 
    // outputDir R:\Internet Archives\Elder Shaver Downloads\In Process\2016_04_04_British Columbia_3_Mar_converted\
    private String processFile(File inDir, File outputDir)  {
        String msgs = "";
        String inNameFolder = inDir.getName(); //name of book folder..use it to rename if files don't match

        File metaInputFile = null;
        File pdfInputFile = null;
        
        if(isNonIA == false){
        File[] fInFiles = inDir.listFiles();//pdf and meta.xml
        //find xml
        for (int x = 0; x < fInFiles.length; x++) {
            if (fInFiles[x].getName().equalsIgnoreCase(inNameFolder + "_meta.xml")) {
                metaInputFile = fInFiles[x];
                break;
            }
        }
        
        for (int x = 0; x < fInFiles.length; x++) {
            if (fInFiles[x].getName().endsWith( "_text.pdf")) {
                pdfInputFile = fInFiles[x];
                msgs += "WARNING, no pdf, copying _text.pdf to: " + inDir.getAbsolutePath() + "\r\n";
                break;
            }  
        }

        if (pdfInputFile == null) {
            for (int x = 0; x < fInFiles.length; x++) {
                if (fInFiles[x].getName().endsWith(".pdf")) {
                    //Spence says that if folder contains .pdf_text, then just rename it and use it
                    //File copy = new File(inDir.getAbsolutePath() + "/" + inNameFolder + ".pdf");//use folder as name model
                    //try{
                        
                      //  this.copyFile(fInFiles[x], copy);
                    //}catch(Exception e){
                       // msgs += "Error copying pdf file " + fInFiles[x].getName() + " to " + copy.getName() + " " +  e.getMessage();  
                    //}
                    pdfInputFile = fInFiles[x];
                    break;
                }
            }
        }
         
        //still no matching pdf, check pdf_text
        if (pdfInputFile == null) {
            for (int x = 0; x < fInFiles.length; x++) {
                if (fInFiles[x].getName().endsWith(".pdf_text")) {
                    //Spence says that if folder contains .pdf_text, then just rename it and use it
                    //File copy = new File(inDir.getAbsolutePath() + "/" + inNameFolder + ".pdf");//use folder as name model
                    //try{
                        
                      //  this.copyFile(fInFiles[x], copy);
                    //}catch(Exception e){
                       // msgs += "Error copying pdf file " + fInFiles[x].getName() + " to " + copy.getName() + " " +  e.getMessage();  
                    //}
                    pdfInputFile = fInFiles[x];
                    msgs += "WARNING, no pdf, copying .pdf_text to: " + inDir.getAbsolutePath() + "\r\n";
                    break;
                }
            }
        }
        //still no pdf, lastly check for any pdf
        if(pdfInputFile == null){
             for(int x = 0; x< fInFiles.length; x++){
                if(fInFiles[x].getName().endsWith(".pdf")){
                    //Spence says that if folder contains .pdf_text, then just rename it and use it
                    //File copy = new File(inDir.getAbsolutePath() + "/" + inNameFolder + ".pdf");//use folder as name model
                    //try{
                        //this.copyFile(fInFiles[x], copy);
                    //}catch(Exception e){
                      //  msgs += "Error copying pdf file " + fInFiles[x].getName() + " to " + copy.getName() + " " +  e.getMessage();
                    //}
                    pdfInputFile = fInFiles[x];
                    msgs += "WARNING, no matching folder and pdf name, copying " + fInFiles[x].getName() + " to " + inDir.getAbsolutePath()+ "\r\n";
                    break;
                }
            }
        }
        }else{
            pdfInputFile = inDir;//pdf gets passed in instead of folder containing it
        }
        
        //still no input files
        if(isNonIA == false && metaInputFile == null){
            msgs = "Error, source meta.xml missing in: " + inDir.getAbsolutePath();
            return msgs +"\r\n";
        }
        if(pdfInputFile == null){
            msgs = "Error, source pdf missing in: " + inDir.getAbsolutePath();
            return msgs+"\r\n";
        }
        //use pdfBox  to get pagecount out of pdf
        //http://pdfbox.apache.org/download.cgi#20x
        int pageCount = 0; 
        if(isNonIA == false){
            try{
                //  PdfReader pdfr = new PdfReader(pdfInputFile.getAbsolutePath());
          
                PDDocument doc = PDDocument.load(pdfInputFile);
                pageCount = doc.getNumberOfPages();
                doc.close();
            }catch(Exception e){
                msgs += "WARNING, cannot get page count from pdf: " + pdfInputFile.getName() + ".  Using count in xml \r\n";             
            }
        }
        //1.  copy meta file
        /*
        try{
            copyFile(metaInputFile, new File(outputDir.getAbsoluteFile() + "/" + inNameFolder + "_meta.xml"));
        }catch(Exception e){
            msgs += "Error while copying file " + metaInputFile.getName() + " " + e.getMessage();
            return msgs+"\r\n";
        }*/
        //2. Copy pdf to new location with no change
        //create .\dcms\assets\airforceregiste1962wash_0
        File pdfOutputDir = new File(outputDir.getAbsoluteFile() + "/dcms/");
        pdfOutputDir.mkdir();
        pdfOutputDir = new File(pdfOutputDir.getAbsoluteFile() + "/assets/");
        pdfOutputDir.mkdir();
        if(isNonIA){
            pdfOutputDir = new File(pdfOutputDir.getAbsoluteFile() + "/" + inNameFolder.substring(0, inNameFolder.length()-4));//trim .pdf off folder
        }else{
            pdfOutputDir = new File(pdfOutputDir.getAbsoluteFile() + "/" + inNameFolder);
        }
        pdfOutputDir.mkdir();
        String newPdfFileName = pdfOutputDir.getName();//same as inNameFolder - use in xml output also in case pdf name was updated by code and diff from input metadata
        pdfOutputDir = new File(pdfOutputDir.getAbsoluteFile()  + "/PRESERVATION_MASTER" );
        pdfOutputDir.mkdir();
         
        File sipOutputDir = new File(outputDir.getAbsoluteFile() + "/dcms/");//all in batch go to same dir
        sipOutputDir.mkdir();
        sipOutputDir = new File(sipOutputDir.getAbsoluteFile() + "/metadata/");//all in batch go to same dir
        sipOutputDir.mkdir();
        
        if(isNonIA == false){
            sipOutputDir = new File(sipOutputDir.getAbsoluteFile() + "/ldssip/");//all in batch go to same dir
            sipOutputDir.mkdir();
        }
      
        File pdfOutputFile = new File(pdfOutputDir.getAbsolutePath() + "/" + newPdfFileName +".pdf");
       
        try{
            copyFile(pdfInputFile, pdfOutputFile);
        }catch(Exception e){
            msgs += "Error while copying file " + pdfInputFile.getName() + " " + e.getMessage();
            return msgs+"\r\n";
        }
        
        //3.  generate and copy sip xml file R:\Internet Archives\Elder Shaver Downloads\In Process\2016_04_28_IA_Florida_Mar_2016_converted\dcms\metadata\ldssip
        File sipOutputFile;
        if(isNonIA){
            sipOutputFile = new File(sipOutputDir + "/" + inNameFolder.substring(0,inNameFolder.length()-4) + ".sip.xml");//trimm off .pdf
        }else{
            sipOutputFile = new File(sipOutputDir + "/" + inNameFolder + ".sip.xml");
        }
        
        if (isNonIA == false) {
            HashMap<String, String> inTagsValues;

            try {
                inTagsValues = parseInputFile(metaInputFile);
            } catch (Exception e) {
                return e.getMessage() + "\r\n";
            }

            String[][] mdValues = new String[30][2];

            int mdIndex = 0;
            try {

                //special processing of certain xml values
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Calendar cal = Calendar.getInstance();
                String dateStamp = dateFormat.format(cal.getTime());
                String fileName = pdfOutputFile.getName();//pdfInputFile.getName();
                String fileSize = String.valueOf(pdfInputFile.length() / 1024) + " KB";

                addedTagsKeys[2][1] = fileName; //{"ldsterms:filename","3347482.pdf"}
                addedTagsKeys[3][1] = fileSize; //{"ldsterms:filesize","20728.24 KB"}
                addedTagsKeys[14][1] = dateStamp; //{"dc:date",""}
                recordValues[3][1] = dateStamp; // {"eventDateTime",dateStamp},

                /*rem 10.22.2016 String propertyRight = inTagsValues.get(translationKeys[7]);
                if (propertyRight == null || "NOT_IN_COPYRIGHT".equalsIgnoreCase(propertyRight)) {
                    inTagsValues.put(translationKeys[7], "Public");
                } else {
                    //just take what is passed in
                }*/
                inTagsValues.put(translationKeys[7], "Public");//10.22.2016

                if (pageCount > 0) {
                    //count from xml above
                    inTagsValues.put(translationKeys[14], String.valueOf(pageCount));//replace pagecount form xmlfile
                }

                //populate array with translated tag names and values passed in from meta.xml
                mdIndex = 0;
                for (int x = 0; x < translationCount; x++) {

                    String k = translationKeys[x];// input tag key
                    String v = translationValues[x];

                    mdValues[mdIndex][0] = v; //value of output key xml tag
                    /*if(mdValues[mdIndex][1] != null) {
                    mdValues[mdIndex][1] += "; " + inTagsValues.get(k);//concatinate prev value
                }else{*/
                    mdValues[mdIndex][1] = inTagsValues.get(k);//value using input tag key
                    //}

                    /*if(k.contains("***")){
                    //dont increment mdIndex
                }else{*/
                    mdIndex++;
                    //  }
                }

                //append addedTag hardcoded tags
                for (int x = 0; x < addedTagsKeys.length; x++) {
                    mdValues[mdIndex][0] = addedTagsKeys[x][0];
                    mdValues[mdIndex][1] = addedTagsKeys[x][1];
                    mdIndex++;
                }

            } catch (Exception e) {
                return msgs + "Error setting metadata xml values of file " + metaInputFile.getName() + "\r\n";
            }

            try {
                Document doc = generateXmlDoc(mdValues, mdIndex, recordValues, sipOutputFile.getName());

                doc.setXmlStandalone(true); //remove standalone=no attr at top

               // FileWriter fw = new FileWriter(sipOutputFile);
                Transformer transformer = TransformerFactory.newInstance().newTransformer();
                Result output = new StreamResult(sipOutputFile);
                Source input = new DOMSource(doc);

                transformer.transform(input, output);
            } catch (Exception e) {
                return msgs + e.getMessage() + "\r\n";
            }
        } else {
             //non IA books get from tfdb xml
             //write to sipOutputFile;
             
	    try {

                URL url = new URL("https://bookscan.ldschurch.org/bookscan/xmlMetadata/getTn/" + inNameFolder.substring(0, inNameFolder.length()-4) );
                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");

                if (conn.getResponseCode() != 200) {
                    return msgs + "Error Could not get xml metadata for " + inNameFolder.substring(0, inNameFolder.length()-4) + " - Failed : HTTP error code : "
                            + conn.getResponseCode() + "\r\n";
                }

                
                //BufferedReader br = new BufferedReader(new InputStreamReader( conn.getInputStream()));

                BufferedReader br = new BufferedReader(new InputStreamReader( conn.getInputStream(), "UTF-8"));

                String output;
                String sipFileContent = "";
                //System.out.println("Output from Server .... \n");
                while ((output = br.readLine()) != null) {
                    sipFileContent += output;
                }

                conn.disconnect();
                
                //write to sip xml file
               // FileWriter fw = new FileWriter(sipOutputFile);
                Writer fw = new BufferedWriter(new OutputStreamWriter(  new FileOutputStream(sipOutputFile), "UTF-8"));
                
                fw.write(sipFileContent);
                fw.close();

            } catch (MalformedURLException e) {
                return msgs +  "Error Could not get xml metadata for " + inNameFolder.substring(0, inNameFolder.length()-4) + " - Error processing sip xml - "
                            + e.getMessage() + "\r\n";
                

            } catch (IOException e) {

                return msgs +  "Error Could not get xml metadata for " + inNameFolder.substring(0, inNameFolder.length()-4) + " - Error processing sip xml - IO Exception - "
                            + e.getMessage() + "\r\n";
            }

	
        }
        return msgs;
    }

    private HashMap<String,String>  parseInputFile(File in) throws Exception{
      
        HashMap<String,String> inputKeyValues = new HashMap<String,String>();
        try{
            /*Scanner scan = new Scanner(in);
            while(true){
                String txt = scan.nextLine();
                
                if(txt.trim().startsWith("<metadata>"))
                    break;
            }
            
            while(true){
                String txt = scan.nextLine();
                if(txt.trim().endsWith("</metadata>"))
                    break;
                else {
                    String[] kv = getKeyValueFromTagLine(txt);
                    String key = kv[0];
                    String value = kv[1];
                    if(inputKeyValues.get(key) == null){
                        inputKeyValues.put(key,value);
                    }else{
                        inputKeyValues.put(key,inputKeyValues.get(key) + "; " + value);
                    }
                }         
            }*/
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(in);
            //doc.getDocumentElement().normalize();
            
            NodeList nList = doc.getElementsByTagName("metadata").item(0).getChildNodes();
            //printNode(doc.getChildNodes());
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
 
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    //System.out.println("\nCurrent Element :" + nNode.getNodeName() + " -> " + nNode.getTextContent());
                    //System.out.println("val->" + nNode.getNodeValue());
                    Element eElement = (Element) nNode;
                    inputKeyValues.put(eElement.getNodeName(), eElement.getTextContent());

		}
            }
        }catch(Exception e){
            throw new Exception("Error parsing input meta.xml file: " + in.getName());
        }
        return inputKeyValues;
    }
    
    private static void printNode(NodeList nodeList) {

        for (int count = 0; count < nodeList.getLength(); count++) {

            Node tempNode = nodeList.item(count);

            // make sure it's element node.
            if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

                // get node name and value
                System.out.println("\nNode Name =" + tempNode.getNodeName() + " [OPEN]");
                System.out.println("Node Value =" + tempNode.getTextContent());

                if (tempNode.hasAttributes()) {

                    // get attributes names and values
                    NamedNodeMap nodeMap = tempNode.getAttributes();

                    for (int i = 0; i < nodeMap.getLength(); i++) {

                        Node node = nodeMap.item(i);
                        System.out.println("attr name : " + node.getNodeName());
                        System.out.println("attr value : " + node.getNodeValue());

                    }

                }

                if (tempNode.hasChildNodes()) {

                    // loop again if has child nodes
                    printNode(tempNode.getChildNodes());

                }

                System.out.println("Node Name =" + tempNode.getNodeName() + " [CLOSE]");

            }

        }
    }

  
    //array[0]=key array[1]=value
    private String[] getKeyValueFromTagLine(String txt){
        int startTag1 = txt.indexOf("<")+1;
        int endTag1 = txt.indexOf(">")-1;
        int vStart = endTag1+2;
        int vEnd = txt.indexOf("<",vStart) ;
        String key = txt.substring(startTag1,endTag1 +1);
        String value = "";
        if(vEnd != -1){
            //if -1 then empty tag
            value = txt.substring(vStart,vEnd );
        }
        
        String[] ret = new String[2];
        ret[0] = key;
        ret[1] = value;
        return ret;
    }
    
    private Document generateXmlDoc(String[][] mdValues, int mdLength, String[][] recordValues, String fileName)throws Exception {

        for (int x = 0; x < mdLength; x++) {
            if (mdValues[x][1] == null) {
                mdValues[x][1] = "";
            }

        }
        for (int x = 0; x < recordValues.length; x++) {

            if (recordValues[x][1] == null) {
                recordValues[x][1] = "";
            }
        }
        try {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            Element rootElement = doc.createElement("lds-sip");
            doc.appendChild(rootElement);

            Element mdElem = doc.createElement("metadata");
            mdElem.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
            mdElem.setAttribute("xmlns:dc", "http://purl.org/dc/elements/1.1/");
            mdElem.setAttribute("xmlns:dcterms", "http:/purl.org/dc/terms/");
            mdElem.setAttribute("xmlns:ldsterms", "http://ldschurch.org/ldsterms/ldsterms.xsd");
            rootElement.appendChild(mdElem);

            //all metadata children
            //ie: <dc:identifier>20996_01</dc:identifier> 
            for (int x = 0; x < mdLength; x++) {

                if ((mdValues[x][0] != null) && ("".equals(mdValues[x][0]) == false)) {
                    Element md = doc.createElement(mdValues[x][0]);
                    md.appendChild(doc.createTextNode(mdValues[x][1]));
                    mdElem.appendChild(md);
                }
            }

            Element dnxElem = doc.createElement("dnx");
            rootElement.appendChild(dnxElem);

            Element sectionElem = doc.createElement("section");
            sectionElem.setAttribute("id", "event");
            dnxElem.appendChild(sectionElem);

            Element recordElem = doc.createElement("record");
            sectionElem.appendChild(recordElem);

            //<key id="eventIdentifierType">Provenance Event</key> 
            for (int x = 0; x < recordValues.length; x++) {
                if ((recordValues[x][0] != null) && ("".equals(recordValues[x][0]) == false)) {
                    Element keyElem = doc.createElement("key");
                    keyElem.setAttribute("id", recordValues[x][0]);//ie  eventIdentifierType
                    keyElem.appendChild(doc.createTextNode(recordValues[x][1]));//ie Provenance Event
                    recordElem.appendChild(keyElem);
                }
            }

            Element assetpathElem = doc.createElement("assetpath");
            String path = "";
            if (fileName.length() > 5) {
                path = fileName.substring(0, fileName.length() - 8);//remove .pdf
            }
            assetpathElem.appendChild(doc.createTextNode(path));
            rootElement.appendChild(assetpathElem);

            Element accessElem = doc.createElement("access");//nonspc
            accessElem.appendChild(doc.createTextNode("nonspc"));
            rootElement.appendChild(accessElem);

            return doc;

        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
            throw e;
        }

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton cancelButton;
    private javax.swing.JTextField destinationLabel;
    private javax.swing.JList<String> filesListBox;
    private javax.swing.JList<String> filesListBoxDest;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JButton openDestFolder;
    private javax.swing.JButton openSourceFolder;
    private javax.swing.JRadioButton radioIA;
    private javax.swing.JRadioButton radioNonIA;
    private javax.swing.JButton runButton;
    private javax.swing.JButton saveProperties;
    private javax.swing.JTextField sourceLabel;
    private javax.swing.JLabel srcPathLabel;
    // End of variables declaration//GEN-END:variables
}
